<?php 
        session_start();

        if(empty($_SESSION["email"])){
            header("location:../login.php");
        }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5 bg-dark text-light">
    <form action="addProducts.php" method="post" enctype="multipart/form-data">
    <div class="mb-3">
        <h1 style="text-align: center;">Add Product</h1>
    </div>
        <div class="mb-3">
            <label for="productName-id" class="form-label">Product Name :</label>
            <input type="text" class="form-control" name="productName" id="productName-id"> 
        </div>
        <div class="mb-3">
            <label for="productImage-id"  class="form-label">Product Image :</label>
            <input type="file" class="form-control" name="productImage" id="productImage-id"/> 
        </div>
        <div class="mb-3">
            <label for="productCategory-id" class="form-label">Product Category :</label>
            <input type="text"  class="form-control" name="productCategory" id="productCategory-id">
        </div>
        <div class="mb-3">
            <label for="productPrice-id" class="form-label">Product Price :</label>
            <input type="text"  class="form-control" name="productPrice" id="productPrice-id">
        </div>
            <input type="submit" class="btn btn-success" name="submit" value="Upload"/>
            <a class="btn btn-warning my-5"  href="../home.php" role="button">Go To Dashboard</a>

    </form>
</div>
                <?php
                include_once '../db.php';
                    if(isset($_POST['submit']) && !empty($_FILES["productImage"]["name"]))
                    {
                        $allowTypes = array('jpg','png','jpeg','gif','pdf','jfif','webp');
                        $productName = $_POST['productName'];
                        $productCategory = $_POST['productCategory'];
                        $productPrice = $_POST['productPrice'];
                        $productImageName = $_FILES["productImage"]["name"];
                        $productImageLocation = $_FILES["productImage"]["tmp_name"];
                        $productImageSize = $_FILES["productImage"]["size"];
                        $target_dir = "images/";
                        $target_file = $target_dir.basename($_FILES["productImage"]["name"]);
                        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


                        if(in_array($imageFileType, $allowTypes)){
                            
                             $qry = "insert into Products(product_name,product_image,product_category,product_price) values('$productName','$target_file','$productCategory','$productPrice')";
                             $result = mysqli_query($con,$qry);

                             if($result){
                                move_uploaded_file($_FILES["productImage"]["tmp_name"], "../".$target_file);
                                header("location:../home.php");
                                echo "uploded sucessfully";

                             }else{
                                 echo "not uploded".mysqli_error($con);
                             }
                            
                        }else{
                            $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
                        }
                    }else{
                        $statusMsg = 'Please select a file to upload.';
                    }
               ?>
</body>
</html>