<?php 
        session_start();

        if(empty($_SESSION["email"])){
            header("location:../login.php");
        }

?>

<?php 
                include_once '../db.php';
                iF(isset($_GET["deleteid"])){
                    $id = $_GET["deleteid"];
                    $sql ="delete from Products where Product_id = $id";
                    $result = mysqli_query($con,$sql);
                    if($result){
                        echo "deleted sucefully";
                        header("location:../home.php");
                    }else{
                        die(mysqli_error($con));
                    }
                }



?>