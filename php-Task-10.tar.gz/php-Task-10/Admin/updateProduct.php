<?php 
        session_start();

        if(empty($_SESSION["email"])){
            header("location:../login.php");
        }

?>
<?php

      include_once '../db.php';
     if(isset($_POST['submit']) && !empty($_FILES["productImage"]["name"]))
                    {
                        $id = $_POST["test"];
                        $allowTypes = array('jpg','png','jpeg','gif','pdf','jfif','webp');
                        $productName = $_POST['productName'];
                        $productCategory = $_POST['productCategory'];
                        $productPrice = $_POST['productPrice'];
                        $productImageName = $_FILES["productImage"]["name"];
                        $productImageLocation = $_FILES["productImage"]["tmp_name"];
                        $productImageSize = $_FILES["productImage"]["size"];
                        $target_dir = "images/";
                        $target_file = $target_dir.basename($_FILES["productImage"]["name"]);
                        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


                        if(in_array($imageFileType, $allowTypes)){
                            
$qry = "update  Products set Product_id = '$id' ,product_name ='$productName',product_image= 'images/$productImageName' ,product_category= '$productCategory',product_price= '$productPrice' where Product_id = '$id'";
                             $result = mysqli_query($con,$qry);

                             if($result){
                                header("location:../home.php");

                             }else{
                                 echo "not uploded".mysqli_error($con);
                             }
                            
                        }else{
                            $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
                        }
                    }else{
                        $statusMsg = 'Please select a file to upload.';
                    }
               ?>


<?php 
   include_once '../db.php';
        $id='';
        $result = '';
        $row = '';
        $name = '';
        $image = '';
        $category = '';
        $price = '';
   if(isset($_GET["updateid"])){
        $id = $_GET["updateid"];
        $sql1 = "select * from Products where Product_id = $id";
        $result = mysqli_query($con,$sql1);
        $row = mysqli_fetch_assoc($result);
        $name =  $row["product_name"];
        $image =  $row["product_image"];
        $category =  $row["product_category"];
        $price =  $row["product_price"];
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
</head>
<body>
<div class="container my-3 bg-dark text-light">

    <form action="updateProduct.php" method="post" enctype="multipart/form-data" onsubmit="return myfun()">
    <div class="mb-3">
        <h1 style="text-align: center;">Edit Product</h1>
    </div>
    
    <div class="mb-3">
       <label for="productName-id" class="form-label">Product Name :</label>
        <input type="text" class="form-control" name="productName" id="productName-id" value=<?php echo $name; ?>> 
    </div>
    <div class="mb-3">
        <label for="productImage-id" class="form-label">Product Image :</label>
        <input type="file" class="form-control" name="productImage" id="productImage-id" >
        <img  class="img-thumbnail" src=<?php echo "../".$image; ?>>
    </div>
    <div class="mb-3">
        <label for="productCategory-id"  class="form-label">Product Category :</label>
        <input type="text"  class="form-control" name="productCategory" id="productCategory-id" value=<?php echo $category; ?>>
    </div>
    <div class="mb-3">
        <label for="productPrice-id"  class="form-label">Product Price :</label>
        <input type="text" class="form-control" name="productPrice" id="productPrice-id"value=<?php echo $price; ?>>
    </div>
        <input type="submit"  class="btn btn-success" name="submit" value="Update"/>
        <input type="hidden" name="test"  value=<?php echo $id;?>>
        <a class="btn btn-primary my-5" href="../home.php" role="button">Go To Dashboard</a>
    </form>

</div>
   <script>
      let filecheck =  document.getElementById("productImage-id");
             function myFun(){ 
                 if(filecheck.value == ''){
                    alert("please select file")
                    return false;
                 }else{
                     return true;
                 }

              }
   </script>
                
</body>
</html>