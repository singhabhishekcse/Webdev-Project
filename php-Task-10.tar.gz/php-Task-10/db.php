<?php 
  
$con = mysqli_connect("localhost","root","","cedcoss");
if(!$con){
    echo "error in connection";

}

  ?>