<?php 
        session_start();

        if(empty($_SESSION["email"])){
            header("location:login.php");
        }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit-profile</title>
    <link rel="stylesheet" href="editProfile.css">
</head>
<body>
    <div class="container">
        <form action="editProfile.php" method="post">
            <span id="sucessfully-id">
                <?php 
                 if(isset($_GET['Message'])){
                    echo $_GET['Message'];
                }
            ?></span> <br> <br>
           <span id="edit-id">Edit Profile</span> <br><br><br>

            <label for="username">Name :</label>
            <input required type="text" name="username" id="username"  value="<?php echo  $_SESSION["username"]; ?>"><span class="error" id="usernameError"></span> <br> <br>
            <label for="email"> Email :</label>
            <input type="email" name="email" id="email" value="<?php echo  $_SESSION["email"]; ?>" disabled> <br> <br>
            <label for="mobile">Mobile :</label>
            <input type="number" name="mobile" id="mobile" value="<?php echo  $_SESSION["mobile"]; ?>" disabled><br><br>
            <label for="password">Password :</label>
            <input required type="password" name="password" id="password" value="<?php echo   $_SESSION["password"]; ?>" ><span class="error" id="passwordError"></span> <br> <br>
            <label for="password">Confirm Password :</label>
            <input required type="password" name="password" id="con-password" value="<?php echo   $_SESSION["password"]; ?>"><span class="error" id="Confirm-passwordError"></span> <br> <br>
            <input type="submit" value="Update" name="update">
            <span  id="gotodashboard-span"><a href="home.php" id="gotodashboard-id">Go to Dashboard</a> </span>
        </form>
    </div>
    <?php 
     if(isset($_POST['update'])){
        $usr = $_POST["username"];
        $pass = $_POST["password"];
        $em = $_SESSION["email"];
        if($usr != '' && $pass != ''){
          include_once 'db.php';
          $q = "update regData  SET username='$usr',password='$pass' where  email = '$em'";
          $result = mysqli_query($con,$q);
          echo  mysqli_error($con);
          $Message = urlencode("Sucessfully Updated !!");
                    header("Location:editProfile.php?Message=".$Message);
                    die;
        }
     }
    ?>
</body>
</html>