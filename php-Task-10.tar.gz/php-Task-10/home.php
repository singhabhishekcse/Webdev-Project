<?php 
        session_start();
        if(empty($_SESSION["email"])){
            header("location:login.php");
        }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="stylesheet" href="homeStyle.css"/>
    <style>
        *{
            margin: 0;
            padding: 0;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container bg-light text-dark my-3">
            <?php  
             $adminEmail = 'admin@admin.com';
                if(!isset($_SESSION["email"])){
                    header("location:login.php");
                }else{ 
               echo "<span class='common' id='username-id'>Welcome <b>".$_SESSION["username"]."</b></span>";
               if($adminEmail !== $_SESSION["email"]){
                echo "<span id='editProfile-span'><a  id='editProfile-id' href='editProfile.php'>Edit Profile</a></span>"; 
                echo "<span id='editProfile-span'><a  id='editProfile-id' href='viewAllProducts.php'>View all products</a></span>";
               }
              
               if($adminEmail == $_SESSION["email"]) {
                echo "<span id='editProfile-span'><a  id='editProfile-id' href='Admin/addProducts.php'>Add Products</a></span>";       
                echo "<span id='editProfile-span'><a  id='editProfile-id' href='Admin/viewAllUser.php'>                View Registered Users
                </a></span>";       
              }
               echo "<a class='btn btn-danger my-3 mx-5' href='logout.php' role='button'>Logout</a>";
                   
            ?>
    
    </div>
   
    <div class="container bg-light text-dark">
                    <table class="table" >
                        <thead>
                            <tr>
                            <th scope="col">Product_id</th>
                            <th scope="col">Product</th>
                            <th scope="col">Images</th>
                            <th scope="col">Price</th>
                            <?php
                            if($adminEmail == $_SESSION["email"]){
                            echo "<th scope='col'>Operation</th>";
                            }
                            ?>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                           include_once 'db.php';
                            $qry1 = "select * from Products";
                             $result = mysqli_query($con,$qry1);
                             $count = 0;
                             while($row = mysqli_fetch_assoc($result)){
                                 $id = $row["Product_id"];
                                 $count++;

                         if($adminEmail == $_SESSION["email"]) {

                              echo"<tr>
                                        <th scope='row'>$count</th>
                                        <td>{$row["product_name"]}</td>
                                        <td>
                                        <div class='card' style='width: 10rem;'>
                                        <img src={$row["product_image"]} alt='img'>
                                        </div></td>
                                        <td>{$row["product_price"]}</td>
                                        <td>
                                        <a class='btn btn-primary' href='Admin/updateProduct.php?updateid=$id' role='button'>Edit</a>
                                        <a class='btn btn-danger' href='Admin/delete.php?deleteid=$id' role='button'>Delete</a>
                                        </td>
                                 
                                </tr>  ";                    
                              }else{
                                echo"<tr>
                                <th scope='row'>$count</th>
                                <td>{$row["product_name"]}</td>
                                <td>
                                <div class='card' style='width: 10rem;'>
                                <img src={$row["product_image"]} alt='img'>
                                </div></td>
                                <td>{$row["product_price"]}</td>
                                
                         
                               </tr>  ";  
                             
                         }
                         }
                        ?>
                        </tbody>
                        </table>
    </div>
<?php 
}
?>
</body>
</html>

    