<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home page</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
     <div class="container">
         <span id="welcome-usr">Hey Welcome To My Website !!</span>
         <img src="https://c.tenor.com/v7I_1mKJOB4AAAAM/huummm-que-rico.gif" alt="img" ><br>
         <div>
         <span class="logsign"><a href="login.php">Log in</a></span>
         <span class="logsign"><a href="reg.php">Sign Up</a></span>
         </div>
     </div>
</body>
</html>