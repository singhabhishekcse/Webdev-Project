<?php 
 session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login </title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <style>
        #regBtn 
        {

            height: 30px;
            background-color: rgb(180, 26, 26);
            border: 2px solid black;
            padding: 4px;
            border-radius: 5px;
        }

        a {
            text-decoration: none;
            font-size: 20px;
            /* padding: 3px; */
            background-color: rgb(180, 26, 26);
            color: white;
            width: 150px;
        }
    </style>
</head>

<body>
    <form action="loginData.php" onsubmit="return validate()" method="post">
    <span class="error">   <?php 
                 if(isset($_GET['usrexits'])){
                    echo $_GET['usrexits'];
                }
            ?></span> <br>
        <label for="username">Email :</label>
        <input type="email" name="email" id="email"> <span class="error" id="usernameError">
            <?php
                   if(isset($_SESSION["emailandpassError"])){
                    $_SESSION["emailandpassError"];
                   }
            ?>
        </span><br> <br>
        <label for="password">Password :</label>
        <input type="password" name="password" id="password"><span class="error" id="passwordError"></span> <br> <br>
        <input type="submit" value="login" name="submit">
        <span id="regBtn"><a href="reg.php">Register</a></span> <br><br>
        <span class="error">
            <?php 
                 if(isset($_GET['Message'])){
                    echo $_GET['Message'];
                }
            ?>
        </span>
    </form>
    <script>
        function validate() {
            if ($("#email").val() == "") {
                $("#usernameError").html("* Please enter you email");
                $("#email").focus();
                return false;
            }else if($("#password").val() == "") {
                $("#passwordError").html('* Please enter you pasword');
                $("#password").focus();
                return false;
            }else {
                return true;
            }
        }
    </script>
</body>

</html>