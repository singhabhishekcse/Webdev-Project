<?php
session_start();

 if(isset($_POST['submit'])){
        include_once 'db.php';
            $email = $_POST["email"];
            $password = $_POST["password"];
        if($email != '' && $password != ''){
                $q = "select * from regData where email = '$email' && password = '$password'";
                $result = mysqli_query($con,$q);
                $num = mysqli_num_rows($result);
                if($num == 1){
                    $_SESSION["email"]=$email;
                    $_SESSION["password"]=$password;
                            $i=0;
                            while($row = mysqli_fetch_array($result)) {
                                $_SESSION["username"] = $row["username"]; 
                                $_SESSION["email"] = $row["email"]; 
                                $_SESSION["mobile"] = $row["mobile"]; 
                                $_SESSION["password"] = $row["password"]; 
                                    $i++;
                            }
                    header("location:home.php");
                }else{
                    $Message = urlencode("please enter an valid email or password");
                        header("Location:login.php?Message=".$Message);
                        die;
                }
            // }
           
        }else{
            $_SESSION["emailandpassError"] = "*please enter valid email or password";
            header("location:login.php");
        }
          
 }else{

     header("location:login.php");
 }


?>
