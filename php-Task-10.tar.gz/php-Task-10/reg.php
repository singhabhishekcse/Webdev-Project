<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration-form</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <style>
        * {
            background-color: rgb(149, 177, 154);
        }

        form {
            margin-left: 50px;
            margin-top: 20px;
            border: 3px solid black;
            padding: 80px;
            width: 50%;
            border-radius: 10px;
            background-color: rgb(255, 204, 204);
        }

        label {
            font-size: 25px;
            font-weight: bolder;
            background-color: rgb(255, 204, 204);

        }

        input {
            height: 20px;
            border-radius: 5px;
            background-color: white;
            font-size: 15px;

        }

        input[type='submit'] {
            /* padding: 10px; */
            height: 30px;
            font-weight: bolder;
            font-style: italic;
            font-size: 20px;
            margin: 10px 0px 0px 20px;
            background-color: rgb(204, 0, 0);
            color: white;
            width: 150px;
            height: 35px;
        }

        input[type='email'] {
            margin-left: 40px;
        }

        textarea {
            margin-left: 20px;
            background-color: white;
        }

        .error {
            color: red;
            font-size: 20px;
            font-weight: bolder;
            background-color: rgb(255, 204, 204);

        }
        #log
        {
            height: 30px;
            background-color: skyblue;
            border: 2px solid black;
            padding: 4px;
            border-radius: 5px;
        }

        a {
            text-decoration: none;
            font-size: 20px;
            /* padding: 3px; */
            background-color: skyblue;
            color: black;
            width: 150px;
        }
    </style>
</head>
<body>
    <form action="registrationData.php" onsubmit="return validate()" method="post">
        <label for="username">Name :</label>
        <input type="text" name="username" id="username"><span class="error" id="usernameError"></span> <br> <br>
        <label for="email"> Email :</label>
        <input type="email" name="email" id="email"><span class="error" id="emailError"></span> <br> <br>
        <label for="mobile">Mobile :</label>
        <input type="number" name="mobile" id="mobile"><span class="error" id="mobileError"></span> <br><br>
        <label for="password">Password :</label>
        <input type="password" name="password" id="password"><span class="error" id="passwordError"></span> <br> <br>
        <label for="password">Confirm Password :</label>
        <input type="password" name="password" id="con-password"><span class="error" id="Confirm-passwordError"></span> <br> <br>
        <input type="submit" value="Register" name="register">
        <span id="log"> <a href="login.php">Login</a> </span><br>
        <span class="error">
        <?php 
                 if(isset($_GET['regerrormessage'])){
                    echo $_GET['regerrormessage'];
                }
            ?>
        </span>
    </form>
    <script>
        function validate() {
            if ($("#username").val() == "") {
                $("#usernameError").html( "* enter your username");
                  $("#username").focus();
                return false;
            }else if($("#email").val() == "") {
                $("#emailError").html("* enter your email");
                $("#email").focus();
                return false;
            }else if ($("#mobile").val() == "") {
                $("#mobileError").html("* please enter a valid mobile");
                $("#mobile").focus();
                return false;
            } else if($("#password").val() == "") {
                $("#passwordError").html("* enter your password");
                $("#password").focus();
                return false;
            }else if ($("#con-password") == "") {
                $("#Confirm-passwordError").html("* enter your city");
                $("#con-password").focus();
                return false;
            }else if($("#password").val() !== $("#con-password").val()){
                $("#Confirm-passwordError").html("* your password is not match");
                return false;
            }else {
                return true;
            }
        }
    </script>
</body>

</html>