<?php
session_start();
 header("location:login.php");
if(isset($_POST['register'])){

            $username = $_POST["username"];
            $email = $_POST["email"];
            $mobile = $_POST["mobile"];
            $password = $_POST["password"];

    if($username != '' && $email != '' && $mobile != '' && $password != ''){
            include_once 'db.php';
            $q = "select * from regData where email = '$email'";
            $result = mysqli_query($con,$q);
            $num = mysqli_num_rows($result);
            if($num == 1){
                echo "Your email is allready registred";
                $usrexits = urlencode("email already exits please login !");
                    header("Location:login.php?Message=".$usrexits);
                    die;
            }else{
                $q2 = "insert into regData (username,email,mobile,password) values('$username','$email','$mobile','$password')";
                mysqli_query($con,$q2);
                }
        }else{
            $regerrormessage = urlencode("*all field is mandatory to fill ");
                    header("Location:reg.php?Message=".$regerrormessage);
                    die;
        }
}else{
    header("location:reg.php");
}

?>
<!-- // && password = '$password'" -->