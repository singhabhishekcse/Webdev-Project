<?php 
        session_start();

        if(empty($_SESSION["email"])){
            header("location:login.php");
        }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<a class="btn btn-primary my-3 mx-5" href="home.php" role="button">Go To Dashboard</a>
<a class="btn btn-danger my-3 mx-2" href="logout.php" role="button">Logout</a>
    <div class="container my-2">
         <h1>Shirts</h1>
                            <div class="container  d-flex flex-row bd-highlight mb-3 flex-wrap mx-5">
                                <?php 
                                include_once 'db.php';
                                    $qry1 = "select * from Products where product_category = 'Shirt'";
                                    $result = mysqli_query($con,$qry1);
                                    while($row = mysqli_fetch_assoc($result)){
                                     echo"
                                     <div class='card  mx-3 my-2' >
                                        <div class='card' >
                                        <img src={$row["product_image"]} alt='img' style='width: 15rem; '>
                                        </div>
                                             <h5 class='card-title'>{$row["product_name"]}</h5>
                                             <p class='card-text'>{$row["product_price"]}</p>
                                     </div>";                    
                                    }
                                ?>
                                </div>

    </div>

    <div class="container my-5"> 
        <h1>T-Shirts</h1>
        <div class="container  d-flex flex-row bd-highlight mb-3 flex-wrap mx-5">
                                <?php 
                                include_once 'db.php';
                                    $qry1 = "select * from Products where product_category = 'T-Shirt'";
                                    $result = mysqli_query($con,$qry1);
                                    while($row = mysqli_fetch_assoc($result)){
                                     echo"
                                     <div class='card  mx-3 my-2' >
                                        <div class='card' >
                                        <img src={$row["product_image"]} alt='img' style='width: 15rem; '>
                                        </div>
                                             <h5 class='card-title'>{$row["product_name"]}</h5>
                                             <p class='card-text'>{$row["product_price"]}</p>
                                     </div>";                    
                                    }
                                ?>
                                </div>
    </div>
    <div class="container my-5"> 
        <h1>Jeans</h1>
        <div class="container  d-flex flex-row bd-highlight mb-3 flex-wrap mx-5">
                                <?php 
                                include_once 'db.php';
                                    $qry1 = "select * from Products where product_category = 'Jeans'";
                                    $result = mysqli_query($con,$qry1);
                                    while($row = mysqli_fetch_assoc($result)){
                                     echo"
                                     <div class='card  mx-3 my-2' >
                                        <div class='card' >
                                        <img src={$row["product_image"]} alt='img' style='width: 15rem; '>
                                        </div>
                                             <h5 class='card-title'>{$row["product_name"]}</h5>
                                             <p class='card-text'>{$row["product_price"]}</p>
                                     </div>";                    
                                    }
                                ?>
                                </div>

    </div>
    <div class="container my-5"> 
        <h1>Shoes</h1>
        <div class="container  d-flex flex-row bd-highlight mb-3 flex-wrap mx-5">
                                <?php 
                                include_once 'db.php';
                                    $qry1 = "select * from Products where product_category = 'Shoes'";
                                    $result = mysqli_query($con,$qry1);
                                    while($row = mysqli_fetch_assoc($result)){
                                     echo"
                                     <div class='card  mx-3 my-2' >
                                        <div class='card' >
                                        <img src={$row["product_image"]} alt='img' style='width: 15rem; '>
                                        </div>
                                             <h5 class='card-title'>{$row["product_name"]}</h5>
                                             <p class='card-text'>{$row["product_price"]}</p>
                                     </div>";                    
                                    }
                                ?>
                                </div>

    </div>
    <div class="container my-5"> 
        <h1>Watches</h1>
        <div class="container  d-flex flex-row bd-highlight mb-3 flex-wrap mx-5">
                                <?php 
                                include_once 'db.php';
                                    $qry1 = "select * from Products where product_category = 'Watch'";
                                    $result = mysqli_query($con,$qry1);
                                    while($row = mysqli_fetch_assoc($result)){
                                     echo"
                                     <div class='card  mx-3 my-2' >
                                        <div class='card'>
                                        <img src={$row["product_image"]} alt='img' style='width: 15rem; '>
                                        </div>
                                             <h5 class='card-title'>{$row["product_name"]}</h5>
                                             <p class='card-text'>{$row["product_price"]}</p>
                                     </div>";                    
                                    }
                                ?>
                                </div>

    </div>
    <a class="btn btn-primary my-3 mx-5" href="home.php" role="button">Go To Dashboard</a>
    <a class="btn btn-danger my-3 mx-2" href="logout.php" role="button">Logout</a>
</body>
</html>